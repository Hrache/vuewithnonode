<?php

class ProductsController
{
    function allProducts()
    {
        
    }
}