<?php

use Illuminate\Database\Eloquent\Model;

class CountriesModel extends Model
{
    protected $table = "countries";
}
