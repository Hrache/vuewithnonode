<?php

use Illuminate\Database\Eloquent\Model;

class ProductOptions extends Model
{
    
}
