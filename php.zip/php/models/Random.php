<?php

use Illuminate\Database\Eloquent\Model;

class Random extends Model
{
    protected $table = 'random';
}